// Configuración completa de tu proyecto Supabase
const SUPABASE_URL = "https://hypxybgvxvpwfqflijty.supabase.co";
const SUPABASE_KEY = "sb_publishable_x6A2XiGzM9F2Qlk9xwBUvA_UK3HoJJzpero";

// Inicializar cliente de Supabase
const { createClient } = window.supabase;
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// Elementos del formulario
const formLogin = document.getElementById('formLogin');
const usuarioInput = document.getElementById('usuario');
const contrasenaInput = document.getElementById('contrasena');
const mensajeDiv = document.getElementById('mensaje');

// Manejar el inicio de sesión
formLogin.addEventListener('submit', async function(e) {
    e.preventDefault();
    mensajeDiv.innerHTML = '';
    
    const usuario = usuarioInput.value.trim();
    const contrasena = contrasenaInput.value.trim();
    
    // Validar que no estén vacíos
    if (!usuario || !contrasena) {
        mostrarMensaje('⚠️ Completa todos los campos', 'error');
        return;
    }
    
    try {
        // Buscar el usuario en la tabla "usuarios"
        const { data, error } = await supabase
            .from('usuarios')
            .select('*')
            .eq('usuario', usuario)
            .eq('contrasena', contrasena)
            .single();
        
        if (error) throw error;
        
        // ✅ Si existe → ir a bienvenida
        window.location.href = `bienvenida.html?usuario=${encodeURIComponent(usuario)}`;
        
    } catch (err) {
        // ❌ Si no existe o hay error
        mostrarMensaje('❌ Usuario o contraseña inválidos', 'error');
    }
});

function mostrarMensaje(texto, tipo) {
    mensajeDiv.innerHTML = `<span class="${tipo}">${texto}</span>`;
}
